<powershell>
echo "$(Get-Date -format T) - DSA Deployment Finished"
</powershell>