#!/bin/bash
rpm -e ds_agent